---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--AUTHOR : SAI RAM KISHAN K J, DISCORD ID : sairamkishan#9290 INSTA ID: sairamkishan30
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

-- Variables to store the GUI elements
local passengerWindow, driverList, dropButton, bookButton, closeButton, taxibookButton, taxicancelButton, locationSelect, taxidutypng
local taxiFactionWindow, bookingDetails, acceptButtons = {}
local dropLocation = nil
local theBlip = false
local taxibg = "[images]/taxibg.png"
local taxibookButtonIMG = "[images]/button_book.png" 
local taxicancelButtonIMG = "[images]/button_cancel.png" 
local locationSelectIMG = "[images]/location.png" 
local taxidutypngIMG = "[images]/taxiduty.png" 

--Variables for ipad body
local screenWidth, screenHeight = guiGetScreenSize()
local ipadBody = "[images]/ipadbody.png"
local ipadWidth, ipadHeight = 0.5625 * screenWidth, 0.69444444444 * screenHeight -- Size of the iPad image
local ipadX, ipadY = (screenWidth - ipadWidth) / 2, (screenHeight - ipadHeight) / 2
local isDragging = false

local TaxiPanelOpen = false
--ipad body and function for itS
function renderIpad()
    dxDrawImage(ipadX , ipadY, ipadWidth , ipadHeight , ipadBody)
end

-- Function to trigger the server-side event when F4 is pressed
function taxiPaneltrigger(button, press)
    if isChatBoxInputActive() then
        return
    end
    if press then
        if button == "F4" then
            triggerServerEvent("processTaxiF4", localPlayer, localPlayer)
        end
    end
end
addEventHandler("onClientKey", root, taxiPaneltrigger)

--close the taxi panel
function closeTaxiPanel()
    if isElement(passengerWindow) then 
        destroyElement(passengerWindow)
        destroyElement(taxibookButton)
        destroyElement(taxicancelButton)
        destroyElement(locationSelect)
        destroyElement(taxidutypng)
        removeEventHandler("onClientRender", root, renderIpad)
        TaxiPanelOpen = false
        showCursor(false)
    elseif isElement(taxiFactionWindow) then 
        destroyElement(taxiFactionWindow)
        removeEventHandler("onClientRender", root, renderIpad)
        TaxiPanelOpen = false
        showCursor(false)
    end
end

--hoover animation
addEventHandler("onClientCursorMove", root,
    function(_, _, x, y)
        if isElement(taxiFactionWindow) then 
            
        elseif isElement(passengerWindow) then 
            if x >= 526/1920 * screenWidth and x <= (526 + 256)/1920 * screenWidth and y >= 233/1080 * screenHeight and y <= (233 + 387)/1080 * screenHeight then --taxiduty
                guiSetAlpha(taxibookButton, 0.6)
                guiSetAlpha(taxicancelButton, 0.6)
                guiSetAlpha(locationSelect, 0.6)
                guiSetAlpha(taxidutypng, 1)
            elseif x >= 1066/1920 * screenWidth and x <= (1066 + 320)/1920 * screenWidth and y >= 231/1080 * screenHeight and y <= (213 + 275)/1080 * screenHeight then -- location
                guiSetAlpha(taxibookButton, 0.6)
                guiSetAlpha(taxicancelButton, 0.6)
                guiSetAlpha(locationSelect, 1)
                guiSetAlpha(taxidutypng, 0.6)
            elseif x >= 527/1920 * screenWidth and x <= (527 + 419)/1920 * screenWidth and y >= 769/1080 * screenHeight and y <= (769 + 84)/1080 * screenHeight then --bookbutton
                guiSetAlpha(taxibookButton, 1)
                guiSetAlpha(taxicancelButton, 0.6)
                guiSetAlpha(locationSelect, 0.6)
                guiSetAlpha(taxidutypng, 0.6)
            elseif x >= 979/1920 * screenWidth and x <= (979 + 419)/1920 * screenWidth and y >= 769/1080 * screenHeight and y <= (769 + 84)/1080 * screenHeight then --cancel ride
                guiSetAlpha(taxibookButton, 0.6)
                guiSetAlpha(taxicancelButton, 1)
                guiSetAlpha(locationSelect, 0.6)
                guiSetAlpha(taxidutypng, 0.6)
            else
                guiSetAlpha(taxibookButton, 0.6)
                guiSetAlpha(taxicancelButton, 0.6)
                guiSetAlpha(locationSelect, 0.6)
                guiSetAlpha(taxidutypng, 0.6)
            end
        end
    end
)

addEventHandler("onClientClick", root,
    function(button, state, x, y)
        if TaxiPanelOpen then 
        -- Check if the click is on the specific button coordinates
            local specificButtonClicked = false
            local specificButtonX = 1423 
            local specificButtonY = 505 

            if button == "left" then
                if state == "down" and TaxiPanelOpen then
                    if x >= ipadX and x <= ipadX + ipadWidth and y >= ipadY and y <= ipadY + ipadHeight then
                        startX, startY = x, y
                        isDragging = true
                    end
                    
                elseif state == "up" then
                    if isDragging then
                        isDragging = false
                        --outputChatBox("x : " .. x .. " ||  y : " .. y )
                        --CLOSE BUTTON
                        if x >= (0.745833 * screenWidth) and x <= (0.745833 * screenWidth) + 55 and y >= (0.478703 * screenHeight) and y <= (0.478703 * screenHeight) + 55 then
                            if isElement(taxiFactionWindow) then 
                                destroyElement(taxiFactionWindow)
                                removeEventHandler("onClientRender", root, renderIpad)
                                TaxiPanelOpen = false
                                showCursor(false)
                            elseif isElement(passengerWindow) then 
                                destroyElement(passengerWindow)
                                destroyElement(taxibookButton)
                                destroyElement(taxicancelButton)
                                destroyElement(locationSelect)
                                destroyElement(taxidutypng)
                                removeEventHandler("onClientRender", root, renderIpad)
                                TaxiPanelOpen = false
                                showCursor(false)
                            end
                        end
                    
                        --TAXI BUTTON FUNCTIONS
                        if isElement(passengerWindow) then 
                            if x >= 1066/1920 * screenWidth and x <= (1066 + 320)/1920 * screenWidth and y >= 231/1080 * screenHeight and y <= (213 + 275)/1080 * screenHeight then -- location
                                toggleCustomMap()
                            elseif x >= 527/1920 * screenWidth and x <= (527 + 419)/1920 * screenWidth and y >= 769/1080 * screenHeight and y <= (769 + 84)/1080 * screenHeight then --bookbutton
                                if dropLocation then
                                    if ( getElementInterior(localPlayer) == 0 ) then
                                        triggerServerEvent("bookTaxi", resourceRoot, localPlayer, dropLocation)
                                        closeTaxiPanel()
                                        removeEventHandler("onClientKey", root, mapControls)
                                        forcePlayerMap(false)
                                        showCursor(false)
                                        dropLocation = nil
                                    else
                                        triggerEvent("add:notification",localPlayer,"TAXI: You cant book a taxi from this location!", "error", true)
                                    end
                                else
                                    triggerEvent("add:notification",localPlayer,"TAXI: Please select a drop location first!", "error", true)
                                end
                            elseif x >= 979/1920 * screenWidth and x <= (979 + 419)/1920 * screenWidth and y >= 769/1080 * screenHeight and y <= (769 + 84)/1080 * screenHeight then --cancel ride
                                triggerServerEvent("cancelBooking", resourceRoot, localPlayer, dropLocation)
                            end
                        end
                    end
                end
            end
        end
    end
)

-- Function to show the taxi faction panel
addEvent("showTaxiFactionPanel", true)
addEventHandler("showTaxiFactionPanel", root, function(bookings)
    if isElement(taxiFactionWindow) then 
        destroyElement(taxiFactionWindow)
        removeEventHandler("onClientRender", root, renderIpad)
        TaxiPanelOpen = false
        showCursor(false)
    else
        TaxiPanelOpen = true
        addEventHandler("onClientRender", root, renderIpad)
        showCursor(true)
        -- Create the taxi faction window
        taxiFactionWindow = guiCreateStaticImage( (ipadX + 0.04255625 * screenWidth), (ipadY + 0.03 * screenHeight), (ipadWidth - 0.086 * screenWidth), (ipadHeight - 0.06 * screenHeight), taxibg, false )
        -- Create a scrollable panel to list bookings
        local myFont = guiCreateFont("[font]/font.ttf", 20)
        local titleFont = guiCreateFont("[font]/font.ttf", 40)
        local title = guiCreateLabel(0.35, 0.01815, 1, 1, "TAXI BOOKINGS  ", true, taxiFactionWindow)
        guiSetFont(title, titleFont)
        guiLabelSetColor(title, 180, 135, 30)

        local passengerButton = guiCreateButton(0.3, 0.88, 0.4, 0.1, "RELOAD BOOKINGS", true, taxiFactionWindow)
            guiSetFont(passengerButton, myFont)
            addEventHandler("onClientGUIClick", passengerButton, function()
                closeTaxiPanel()
                triggerServerEvent("processTaxiF4", localPlayer, localPlayer)
            end, false)

        bookingDetails = guiCreateScrollPane(0.02, 0.1, 0.95, 0.75, true, taxiFactionWindow)
        for i, booking in ipairs(bookings) do
            local bookingInfo = string.format("#%d - ID: %s || Name: %s || Distance: %.2f meters || Fare: $%.2f", i, booking.playerID, booking.playerAccount, booking.distance, booking.fare)

            -- Create accept button for each booking
            local button = guiCreateButton(0.05, (i - 1.165) * 0.11, 0.95, 0.1, bookingInfo, true, bookingDetails)
            guiSetFont(button, myFont)
            addEventHandler("onClientGUIClick", button, function()
                triggerServerEvent("acceptTaxiBooking", localPlayer, localPlayer, i)
                closeTaxiPanel()
            end, false)
        end
    end
end)

-- Function to show the passenger panel
addEvent("showPassengerPanel", true)
addEventHandler("showPassengerPanel", root, 
function(drivers)
    if isElement(passengerWindow) then 
        destroyElement(passengerWindow)
        destroyElement(taxibookButton)
        destroyElement(taxicancelButton)
        destroyElement(locationSelect)
        destroyElement(taxidutypng)
        removeEventHandler("onClientRender", root, renderIpad)
        TaxiPanelOpen = false
        showCursor(false)
    else
        TaxiPanelOpen = true
        addEventHandler("onClientRender", root, renderIpad)
        showCursor(true)
        -- Create the main window
        passengerWindow = guiCreateStaticImage( (ipadX + 0.04255625 * screenWidth), (ipadY + 0.03 * screenHeight), (ipadWidth - 0.086 * screenWidth), (ipadHeight - 0.06 * screenHeight), taxibg, false )

        --create other menus
        taxibookButton = guiCreateStaticImage( (ipadX + 0.04255625 * screenWidth), (ipadY + 0.03 * screenHeight), (ipadWidth - 0.086 * screenWidth), (ipadHeight - 0.06 * screenHeight), taxibookButtonIMG, false )
        taxicancelButton = guiCreateStaticImage( (ipadX + 0.04255625 * screenWidth), (ipadY + 0.03 * screenHeight), (ipadWidth - 0.086 * screenWidth), (ipadHeight - 0.06 * screenHeight), taxicancelButtonIMG, false )
        locationSelect  = guiCreateStaticImage( (ipadX + 0.04255625 * screenWidth), (ipadY + 0.03 * screenHeight), (ipadWidth - 0.086 * screenWidth), (ipadHeight - 0.06 * screenHeight), locationSelectIMG , false )  
        taxidutypng   = guiCreateStaticImage( (ipadX + 0.04255625 * screenWidth), (ipadY + 0.03 * screenHeight), (ipadWidth - 0.086 * screenWidth), (ipadHeight - 0.06 * screenHeight), taxidutypngIMG , false )  
      
        guiSetAlpha(taxibookButton, 0.6)
        guiSetAlpha(taxicancelButton, 0.6)
        guiSetAlpha(locationSelect, 0.6)
        guiSetAlpha(taxidutypng, 0.6)
        -- Create the scroll panel for driver list
        driverList = guiCreateScrollPane(0.06, 0.16, 0.25, 0.45, true, taxidutypng)
        local myFont = guiCreateFont("[font]/font.ttf", 20)
            
        -- Populate driver list with real taxi driver data
        for i, driver in ipairs(drivers) do
            local DriverName = guiCreateLabel(0.05, (i - 1) * 0.1, 0.9, 0.1, driver, true, driverList)
            guiSetFont(DriverName, myFont)
            guiLabelSetColor(DriverName, 180, 135, 30)
        end
    end
end)

-- Function to toggle the custom map for selecting drop location
function toggleCustomMap()
    if isPlayerMapVisible() then
        removeEventHandler("onClientKey", root, mapControls)
        forcePlayerMap(false)
        showCursor(false)
    else
        closeTaxiPanel()
        TaxiPanelOpen = false
        addEventHandler("onClientKey", root, mapControls)
        forcePlayerMap(true)
        showCursor(true)
    end
end

-- Function to handle map clicks for setting the drop location
function mapClick(cursorPosX, cursorPosY)
    if getWorldPositionFromMapPosition(cursorPosX, cursorPosY, true) then
        if isElement(theBlip) then
            destroyElement(theBlip)
            theBlip = nil
            playSoundFrontEnd(40)
        else
            local posX, posY, posZ = getWorldPositionFromMapPosition(cursorPosX, cursorPosY, true)
            theBlip = createBlip(posX, posY, posZ)
            dropLocation = {posX, posY}
            triggerEvent("add:notification",localPlayer,"TAXI: Drop location selected successfully", "success", true)
            playSoundFrontEnd(40)
            destroyElement(theBlip)
            theBlip = nil
            forcePlayerMap(false)
            removeEventHandler("onClientKey", root, mapControls)
            --OPEN THE PASSENGER PANEL
            setTimer(function()
                triggerServerEvent("processTaxiCommand", localPlayer, localPlayer)
            end, 50, 1)
        end
    end
end

-- Function to map controls
function mapControls(button, pressing)
    if pressing then
        if button == "mouse1" then
            local cursorPos = Vector2(getCursorPosition())
            mapClick(cursorPos.x, cursorPos.y)
        elseif button == "mouse2" then
            toggleCustomMap()
        end
    end
end

-- Utility function to get world position from map position
function getWorldPositionFromMapPosition(cursorX, cursorY, relative)
    if relative then
        local screen = Vector2(guiGetScreenSize())
        cursorX, cursorY = cursorX * screen.x, cursorY * screen.y
    end
    local mx, my, Mx, My = getPlayerMapBoundingBox()
    local mapMin = Vector2(mx, my)
    local mapMax = Vector2(Mx, My)
    if cursorX >= mapMin.x and cursorY >= mapMin.y and cursorX <= mapMax.x and cursorY <= mapMax.y then
        local relPos = Vector2((cursorX - mapMin.x) / (mapMax.x - mapMin.x), (cursorY - mapMin.y) / (mapMax.y - mapMin.y))
        local worldPlanePos = Vector2(6000 * (relPos.x - 0.5), 3000 - (relPos.y * 6000))
        return worldPlanePos.x, worldPlanePos.y, getGroundPosition(worldPlanePos.x, worldPlanePos.y, 530)
    end
    return false
end

addEventHandler("onClientResourceStart", resourceRoot, 
    function()
        forcePlayerMap(false)
        showCursor(false)
    end
)