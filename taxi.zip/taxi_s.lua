---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--AUTHOR : SAI RAM KISHAN K J, DISCORD ID : sairamkishan#9290 INSTA ID: sairamkishan30
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------
-- Function to handle the taxi command (for passengers)
---------------------------------------------------------------------------------------

local function handleTaxiCommand(player)
    local playerAccount = getPlayerAccount(player)
    if not isGuestAccount(playerAccount) then
        -- Collect all taxi drivers
        local taxiDrivers = {}
        for _, p in ipairs(getElementsByType("player")) do
            local pAccount = getPlayerAccount(p)
            if not isGuestAccount(pAccount) and isObjectInACLGroup("user." .. getAccountName(pAccount), aclGetGroup(taxiACLGroup)) then
                table.insert(taxiDrivers, getAccountName(pAccount))
            end
        end
        -- Show the passenger panel
        triggerClientEvent(player, "showPassengerPanel", player, taxiDrivers)
    else
        triggerClientEvent(player, "add:notification", player, "You need to be logged in to use the taxi service", "error",true)
    end
end

---------------------------------------------------------------------------------------
-- Function to handle F4 key press (for taxi drivers)
---------------------------------------------------------------------------------------

local function handleTaxiF4(player)
    local playerAccount = getPlayerAccount(player)
    if not isGuestAccount(playerAccount) then
        local accountName = getAccountName(playerAccount)
        if isObjectInACLGroup("user." .. accountName, aclGetGroup(taxiACLGroup)) then
            -- If player is in the taxi ACL group, show the taxi faction panel
            triggerClientEvent(player, "showTaxiFactionPanel", player, bookingList)
        end
    end
end

-- Registering the server-side events
addEvent("processTaxiCommand", true)
addEventHandler("processTaxiCommand", root, handleTaxiCommand)

addEvent("processTaxiF4", true)
addEventHandler("processTaxiF4", root, handleTaxiF4)

-- Command handler that triggers the server-side event
addCommandHandler("taxi",
    function(player)
        -- Trigger the event directly from the server-side
        triggerEvent("processTaxiCommand", player, player)
    end
)


---------------------------------------------------------------------------------------
-- Function to handle taxi booking
---------------------------------------------------------------------------------------

addEvent("bookTaxi", true)
addEventHandler("bookTaxi", root, function(player, dropLocation)
    local playerID = getElementData(player, "id") or getPlayerName(player)
    local playerAccount = getAccountName(getPlayerAccount(player))
    local playerX, playerY, _ = getElementPosition(player)
    -- Check if playerAccount already has a booking
    for _, booking in ipairs(bookingList) do
        if booking.playerAccount == playerAccount then
            --outputChatBox("You already have an active booking.", player, 255, 0, 0)
            triggerClientEvent(player, "add:notification", player, "TAXI: You already have an active booking", "error",true)
            return
        end
    end
    local travelDistance = getDistanceBetweenPoints2D(playerX, playerY, dropLocation[1], dropLocation[2])
    local farePrice = math.floor(travelDistance * taxiFeePerMeter)
    -- Add booking to the list
    table.insert(bookingList, {
        playerID = playerID, 
        playerAccount = playerAccount, 
        distance = travelDistance, 
        fare = farePrice, 
        dropLocation = dropLocation
    })
    triggerClientEvent(player, "add:notification", player, "TAXI: TAXI BOOKED SUCCESSFULL", "success",true)
    triggerClientEvent(player, "add:notification", player, "TAXI: TAXI FARE: ".. farePrice .."$", "warn",true)
    outputChatBox("------------------------------", player, 139,69,19)
    outputChatBox("Taxi Booking SUCCESSFULL", player, 50,205,50)
    outputChatBox("FARE AMOUNT: $" .. farePrice, player, 218,165,32)
    outputChatBox("------------------------------", player, 139,69,19)
    -- Notify all taxi drivers
    for _, player in ipairs(getElementsByType("player")) do
        if isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(player)), aclGetGroup(taxiACLGroup)) then
            triggerClientEvent(player, "add:notification", player, "TAXI: NEW TAXI BOOKING AVAILABLE", "success",true)
        end
    end
end)

-- Event to handle cancelling a booking
addEvent("cancelBooking", true)
addEventHandler("cancelBooking", root, function(player)
    local playerAccount = getAccountName(getPlayerAccount(player))
    local bookingFound = false

    for i, booking in ipairs(bookingList) do
        if booking.playerAccount == playerAccount then
            table.remove(bookingList, i)
            --outputChatBox("Your booking has been cancelled.", player, 0, 255, 0)
            triggerClientEvent(player, "add:notification", player, "TAXI: TAXI BOOKED CANCELLED", "warn",true)
            bookingFound = true
            break
        end
    end

    if not bookingFound then
        --outputChatBox("You do not have any active bookings to cancel.", player, 255, 0, 0)
        triggerClientEvent(player, "add:notification", player, "TAXI: NO ACTIVE BOOKING FOUND", "error",true)
    end
end)

---------------------------------------------------------------------------------------
-- Function to handle taxi acceptance
---------------------------------------------------------------------------------------
addEvent("acceptTaxiBooking", true)
addEventHandler("acceptTaxiBooking", root, function(driver, bookingIndex)
    local booking = bookingList[bookingIndex]
    if booking then 
        if isPedInVehicle(driver) then
            -- Get the player who booked the taxi
            local passenger = getAccountPlayer(getAccount(booking.playerAccount))
            if passenger then
                -- Find the closest checkpoint to the passenger's location
                local passengerX, passengerY, passengerZ = getElementPosition(passenger)
                local driverX, driverY, driverZ = getElementPosition(driver)

                local distanceBetweenPlayers = getDistanceBetweenPoints3D(driverX, driverY, driverZ, passengerX, passengerY, passengerZ)
                
                if distanceBetweenPlayers < minDistanceToTeleportDriver then
                    triggerClientEvent(driver, "add:notification", driver, "No Teleportation as you are near the passenger", "warn",true)
                    triggerClientEvent(driver, "add:notification", driver, "distance between players: " .. distanceBetweenPlayers, "success",true)
                else
                    triggerClientEvent(driver, "add:notification", driver, "distance between players: " .. distanceBetweenPlayers, "success",true)
                    local closestCheckpoint = checkpoints[1]
                    local closestDistance = getDistanceBetweenPoints2D(passengerX, passengerY, closestCheckpoint[1], closestCheckpoint[2])
                    for _, checkpoint in ipairs(checkpoints) do
                        local distance = getDistanceBetweenPoints2D(passengerX, passengerY, checkpoint[1], checkpoint[2])
                        if distance < closestDistance then
                            closestCheckpoint = checkpoint
                            closestDistance = distance
                        end
                    end
                    -- Teleport the driver to the closest checkpoint
                    local vehicle = getPedOccupiedVehicle(driver)  
                    if vehicle then 
                        setElementVelocity(vehicle,0,0,0) 
                        setElementPosition ( vehicle, closestCheckpoint[1], closestCheckpoint[2], closestCheckpoint[3]) 
                    end   
                    --outputChatBox("teleporting to closest checkpoint", driver)
                    triggerClientEvent(driver, "add:notification", driver, "teleporting to closest checkpoint", "warn",true)
                end

                
                -- Notify the driver and the passenger
                triggerClientEvent(driver, "add:notification", driver, "You have accepted a taxi booking from || NAME: " .. getAccountName(getPlayerAccount(passenger)) .. " || Fare: $".. booking.fare, "success",true)
                triggerClientEvent(passenger, "add:notification", passenger, "Your taxi booking has been accepted by || DRIVER NAME: " ..getAccountName(getPlayerAccount(driver)) .. "|| Fare: $".. booking.fare, "success",true)

                --message to passenger
                outputChatBox("------------------------------", passenger, 199,21,133)
                outputChatBox("Taxi BOOKING Details", passenger, 218,165,32)
                outputChatBox("DRIVER DETAILS: ", passenger, 218,165,32)
                outputChatBox("    NAME: " .. getAccountName(getPlayerAccount(driver)), passenger, 0, 139, 139)
                outputChatBox("    DRIVER PHONE: " .. (getElementData(driver, PhoneNumberElementData) or "not-found"), passenger, 0, 139, 139)
                outputChatBox("FARE AMOUNT: $" ..  booking.fare, passenger, 218,165,32)
                outputChatBox("------------------------------", passenger, 199,21,133)

                --message to driver
                outputChatBox("------------------------------", driver, 199,21,133)
                outputChatBox("Taxi BOOKING Details", driver, 218,165,32)
                outputChatBox("PASSENGER DETAILS: ", driver, 218,165,32)
                outputChatBox("    NAME: " .. getAccountName(getPlayerAccount(passenger)), driver, 0, 139, 139)
                outputChatBox("    PASSENGER PHONE: " .. (getElementData(passenger, PhoneNumberElementData) or "not-found"), driver, 0, 139, 139)
                outputChatBox("FARE AMOUNT: $" ..  booking.fare, driver, 218,165,32)
                outputChatBox("------------------------------", driver, 199,21,133)

                -- Remove the booking from the list
                table.remove(bookingList, bookingIndex)

                --create checkpoint
                createCheckpointForPlayer(driver, passengerX, passengerY, passengerZ, booking.dropLocation[1], booking.dropLocation[2], 13, 244, 141, 161, passenger)
            else
                triggerClientEvent(driver, "add:notification", driver, "TAXI: Passenger Not Found", "error",true)
            end
        else
            triggerClientEvent(driver, "add:notification", driver, "TAXI: You can only accept bookings from inside a vehicle", "error",true)
        end
    else 
        triggerClientEvent(driver, "add:notification", driver, "TAXI: Booking Not Found", "error",true)
    end
end)

-- Utility function to calculate 2D distance
function getDistanceBetweenPoints2D(x1, y1, x2, y2)
    return math.sqrt((x2 - x1) ^ 2 + (y2 - y1) ^ 2)
end

---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
-- Create check point bLIP
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
local playerCheckpoints = {} -- Store player checkpoints
local playerDropPoints = {} -- Store player drop points

---------------------------------------------------------------------------------------
-- Function to create a checkpoint and marker for a player
---------------------------------------------------------------------------------------
function createCheckpointForPlayer(player, x, y, z, dropX, dropY, dropZ, r, g, b, passenger)
    -- Destroy any existing checkpoint for the player
    if playerCheckpoints[player] then
        destroyElement(playerCheckpoints[player].checkpoint)
        destroyElement(playerCheckpoints[player].blip)
        playerCheckpoints[player] = nil
    end
    -- Create a new checkpoint and blip
    local checkpoint = createMarker(x, y, z, "checkpoint", taxiMarkerSize, r, g, b, taxiBlipAlpha, resourceRoot)
    setMarkerSize(checkpoint, taxiMarkerSize)
    local blip = createBlipAttachedTo(checkpoint, 0, taxiBlipSize, r, g, b, taxiBlipAlpha, 0, 99999, resourceRoot)
    -- Store the checkpoint and drop point coordinates
    playerCheckpoints[player] = {checkpoint = checkpoint, blip = blip, dropX = dropX, dropY = dropY, dropZ = dropZ, player = player, passenger = passenger}
    -- Make the drop point and blip visible to the player
    setElementVisibleTo(checkpoint, player, true)
    setElementVisibleTo(blip, player, true)
end

---------------------------------------------------------------------------------------
-- Function to create a droppoint and marker for a player
---------------------------------------------------------------------------------------
function createDroppointForPlayer(player, passenger, x, y, z, r, g, b)
    -- Destroy any existing drop point for the player
    if playerDropPoints[player] then
        destroyElement(playerDropPoints[player].checkpoint)
        destroyElement(playerDropPoints[player].blip)
        playerDropPoints[player] = nil
    end
    -- Create a new drop point and blip
    local checkpoint = createMarker(x, y, z, "checkpoint", taxiMarkerSize, r, g, b, taxiBlipAlpha, resourceRoot)
    setMarkerSize(checkpoint, taxiMarkerSize)
    local blip = createBlipAttachedTo(checkpoint, 0, taxiBlipSize, r, g, b, taxiBlipAlpha, 0, 99999, resourceRoot)
    -- Store the drop point data
    playerDropPoints[player] = {checkpoint = checkpoint, blip = blip, player = player, passenger = passenger}
    -- Make the drop point and blip visible to the player
    setElementVisibleTo(checkpoint, player, true)
    setElementVisibleTo(blip, player, true)
end

---------------------------------------------------------------------------------------
-- Function to handle player position check when hitting a marker
---------------------------------------------------------------------------------------
function checkPlayerPosition()
    local player = source
    local checkpointData = playerCheckpoints[player]
    local dropPointData = playerDropPoints[player]
    if checkpointData and checkpointData.checkpoint and isElement(checkpointData.checkpoint) then
        local passenger = checkpointData.passenger
        local x, y, z = getElementPosition(player)
        local checkpointX, checkpointY, checkpointZ = getElementPosition(checkpointData.checkpoint)
        local distance = getDistanceBetweenPoints2D(x, y, checkpointX, checkpointY)
        if distance <= taxiMarkerHitRadius then
            destroyElement(checkpointData.checkpoint)
            destroyElement(checkpointData.blip)
            playerCheckpoints[player] = nil -- Remove checkpoint data for the player
            triggerClientEvent(player, "add:notification", player, "PICKUP LOCATION OF PASSENGER: " .. getAccountName(getPlayerAccount(passenger)) ..", REACHED", "success", true)
            triggerClientEvent(passenger, "add:notification", passenger, "DRIVER: " .. getAccountName(getPlayerAccount(player)) .. ", REACHED YOUR LOCATION", "success", true)
            
            -- Create drop point for the player
            local dropX, dropY, dropZ = checkpointData.dropX, checkpointData.dropY, checkpointData.dropZ
            createDroppointForPlayer(player, passenger, dropX, dropY, dropZ, 100, 0, 200)
        end
    end
    if dropPointData and dropPointData.checkpoint and isElement(dropPointData.checkpoint) then
        local passenger = dropPointData.passenger
        local x, y, z = getElementPosition(player)
        local checkpointX, checkpointY, checkpointZ = getElementPosition(dropPointData.checkpoint)
        local distance = getDistanceBetweenPoints2D(x, y, checkpointX, checkpointY)
        if distance <= taxiMarkerHitRadius then
            destroyElement(dropPointData.checkpoint)
            destroyElement(dropPointData.blip)
            playerDropPoints[player] = nil -- Remove drop point data for the player
            triggerClientEvent(player, "add:notification", player, "DROP LOCATION REACHED FOR PASSENGER: ".. getAccountName(getPlayerAccount(passenger)), "success", true)
            triggerClientEvent(passenger, "add:notification", passenger, "DROP LOCATION REACHED", "success", true)
            triggerClientEvent(passenger, "add:notification", passenger, "PAY THE FARE PRICE TO THE DRIVER: " .. getAccountName(getPlayerAccount(player)) , "warn", true)
        end
    end
end
addEventHandler("onPlayerMarkerHit", root, checkPlayerPosition)

---------------------------------------------------------------------------------------