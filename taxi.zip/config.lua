---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--AUTHOR : SAI RAM KISHAN K J, DISCORD ID : sairamkishan#9290 INSTA ID: sairamkishan30
---------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------

taxiACLGroup = "Taxi"

taxiFeePerMeter = 5

checkpoints = {
    {1500, -1300, 13}, {1700, -1400, 13}, {1600, -1350, 13},
    {1800, -1200, 13}, {1400, -1500, 13}, {1300, -1600, 13},
    {1900, -1100, 13}, {1100, -1700, 13}, {1200, -1650, 13},
    {344, -1761, 13}
}

PhoneNumberElementData = "id"

minDistanceToTeleportDriver = 200

-- Marker and Blip configurations
taxiMarkerSize = 15        -- Size of the checkpoint marker
taxiMarkerHitRadius = 15   -- Hit radius of the marker (how close you need to be to trigger it)
taxiBlipSize = 2          -- Size of the radar blip (default is 2)
taxiBlipAlpha = 150       -- Alpha/transparency of the blip (0-255)

---------------------------------------------------------------------------------------
-- ONLY TOUCH BELOW IF YOU KNOW WHAT YOU ARE DOING
---------------------------------------------------------------------------------------
bookingList = {}
---------------------------------------------------------------------------------------